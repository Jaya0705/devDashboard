const AppAction =()=> {
    
    return {
                type : "DISPLAY_APPLICATION",
           }
        
}

export default AppAction;
