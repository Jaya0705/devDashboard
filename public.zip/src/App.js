// import React from 'react';
// import logo from './logo.svg';
// import './App.css';
// import 'bootstrap/dist/css/bootstrap.min.css';
// import {Nav} from 'react-bootstrap';
// import './css/Linkstyle.css';

// function App() {
//   return (
//       <div>
//           <Nav className="justify-content-end" activeKey="/home" style={{backgroundColor: "black"}}>
//               <Nav.Item>
//                   <Nav.Link href="/home">Home</Nav.Link>
//               </Nav.Item>
//               <Nav.Item>
//                   <Nav.Link eventKey="link-1">Link</Nav.Link>
//               </Nav.Item>
//               <Nav.Item>
//                  <Nav.Link eventKey="link-2">Link</Nav.Link>
//               </Nav.Item>
//               <Nav.Item>
//                 <Nav.Link eventKey="disabled" disabled>
//                   DEV DASHBOARD
//                 </Nav.Link>
//               </Nav.Item>
//           </Nav>
//       </div>    
//   );
// }

// export default App;
